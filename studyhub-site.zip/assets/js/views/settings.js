/* 设置 · 考试日期 / 演示模式 / 导入导出 / 清空 / 意图模板一览 */
(function (global) {
  'use strict';
  var St = global.StudyHub.state, ui = global.StudyHub.ui, store = global.StudyHub.store;

  function render(host) {
    var s = St.settings();
    var isDemo = store.profile() === 'demo';
    var intents = global.StudyHubData.intents;

    host.innerHTML =
      '<div class="view-inner">' +
      '<div class="card"><h2>设置</h2>' +
      '<div class="form-row"><label>四级考试日期</label>' +
      '<input id="examDate" type="date" value="' + s.examDate + '" /></div>' +
      '<p class="muted">' + s.examDateNote + '；今天距考试还有 <b>' +
      Math.max(0, St.daysUntil(s.examDate)) + '</b> 天。</p>' +
      '<div class="form-row"><label>自适应新词配额</label>' +
      '<input id="adaptiveQ" type="checkbox"' + (s.adaptive !== false ? ' checked' : '') + ' />' +
      '<span class="muted small">开启时，昨天错题 ≥3 道或今日到期复习词 >40 个，新词自动减半</span></div>' +
      '</div>' +
      '<div class="card"><h3>数据</h3>' +
      '<div class="row-actions">' +
      '<button id="demoToggle" class="btn">' + (isDemo ? '切回我的数据' : '查看演示数据') + '</button>' +
      '<button id="exportBtn" class="btn">导出 JSON</button>' +
      '<label class="btn file-btn">导入 JSON<input id="importFile" type="file" accept=".json" hidden /></label>' +
      '<button id="clearBtn" class="btn danger">清空当前档案</button>' +
      '</div>' +
      (isDemo ? '<p class="muted">当前在看演示数据，改动不会影响你自己的记录。</p>' : '') +
      '<p class="muted" id="setMsg"></p>' +
      '</div>' +
      '<div class="card"><h3>意图模板一览</h3>' +
      '<p class="muted">收件箱就靠这些模板把一句话拆成待办，共 ' + intents.length + ' 类：</p>' +
      '<ul class="intent-list">' +
      intents.map(function (it) {
        return '<li><b>' + ui.esc(it.name) + '</b>' +
          '<span class="muted">关键词：' + it.keywords.map(ui.esc).join(' / ') + '</span>' +
          '<ol>' + it.outputs.map(function (o) {
            return '<li>' + ui.esc(o.title.replace(/\{[^}]*\|([^}]*)\}/g, '$1')) +
              '（约 ' + o.minutes + ' 分钟）</li>';
          }).join('') + '</ol></li>';
      }).join('') +
      '</ul></div></div>';

    function msg(t) { host.querySelector('#setMsg').textContent = t; }

    host.querySelector('#examDate').addEventListener('change', function (e) {
      if (!e.target.value) return;
      St.saveSettings({ examDate: e.target.value });
      render(host);
    });
    host.querySelector('#adaptiveQ').addEventListener('change', function (e) {
      St.saveSettings({ adaptive: e.target.checked });
      render(host);
    });
    host.querySelector('#demoToggle').addEventListener('click', function () {
      var next = isDemo ? 'real' : 'demo';
      store.setProfile(next);
      if (next === 'demo') global.StudyHub.demo.seed();
      global.StudyHub.app.header();
      render(host);
    });
    host.querySelector('#exportBtn').addEventListener('click', function () {
      store.download('studyhub-backup-' + St.dateKey() + '.json',
        JSON.stringify(store.exportData(), null, 2));
      msg('已导出备份文件。');
    });
    host.querySelector('#importFile').addEventListener('change', function (e) {
      var f = e.target.files[0];
      if (!f) return;
      var rd = new FileReader();
      rd.onload = function () {
        try {
          msg(store.importData(JSON.parse(rd.result)) + '。');
          global.StudyHub.app.header();
        } catch (err) { msg('导入失败：' + err.message); }
      };
      rd.readAsText(f);
    });
    host.querySelector('#clearBtn').addEventListener('click', function () {
      if (!confirm('确定清空「' + (isDemo ? '演示数据' : '我的数据') + '」？此操作不可恢复。')) return;
      store.clear();
      render(host);
    });
  }

  global.StudyHub.views = global.StudyHub.views || {};
  global.StudyHub.views.settings = { render: render };
})(window);
